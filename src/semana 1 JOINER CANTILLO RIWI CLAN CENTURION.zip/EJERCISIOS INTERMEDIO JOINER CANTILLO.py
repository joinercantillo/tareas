#task 1
helados = []

print("BIENVENIDO A HELADERIA **** SELECIONE LOS SABORES DE SU PREFERENCIA")
   
print("-1- VAINILLA ")
print("-2- CHOCOLATE")
print("-3- FRESA")

for i in range(1, 6): 
    
    opcion = int(input())

    
    helados.append(opcion)
        
sum = helados.count(1)
sum2 = helados.count(2)
sum3 = helados.count(3)    
print("- Sus pedidos son:") 
print("VAINILLA: ", sum )
print("CHOCOLATE: ", sum2) 
print("FRESA: ", sum3 )              

#task 2

print("BIENVENIDO AL GIMNASIO **** ")
print("INGRESE SU EDAD: ")
edad = int(input())

if edad < 13:
    print("no puede ingresar")
elif edad in range(13, 17):
    print("clase juvenil")