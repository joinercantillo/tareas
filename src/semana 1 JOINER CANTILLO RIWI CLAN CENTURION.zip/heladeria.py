print('BIENVENIDO A HELADERIA ****')
validation = 0
helados = {'cono': 3000, 'vaso': 4000, 'banana split': 9000}
precios = []
vecesllamado = []
validation = -1
count = 0
while validation != 0:
    while validation == 1:
        count =+ 1
    producto = int(input('TENEMOS LOS SIGUIENTES SERVICIOS \n -1- cono \n -2- vaso \n -3- banana split \n escoja una de las opciones' ))
    if producto == 1:
        cantidad = int(input('cuantos helados quiere?'))
        total = cantidad * helados['cono']           
        precios.append(total)
        vecesllamado.append(1)

    elif producto == 2:
        cantidad = int(input('cuantos helados quiere?'))
        total = cantidad * helados['vaso']           
        precios.append(total)
        vecesllamado.append(2)

    elif producto == 3:
        cantidad = int(input('cuantos helados quiere?'))
        total = cantidad * helados['banana split']           
        precios.append(total)
        vecesllamado.append(3)
    validation = int(input('desea comprar otro helado?(y=1/n=0)'))
    
suma = sum(precios)
print('total  vendido: ', suma)
print('se atendieron', count, 'clientes')
num = max(set(vecesllamado), key=vecesllamado.count)
if num == 1:
    print('el helado mas comprado fue cono')
elif num == 2:
    print('el helado mas comprado fue vaso')
elif num == 3:    
    print('el helado mas comprado fue banana split')
